SHA1 Hash of the related GTFS File:
b5c450266161dfa47b548672aa5809d4d7814eb5